package jp.co.sss.shop.controller.login;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jp.co.sss.shop.bean.UserBean;
import jp.co.sss.shop.form.LoginForm;
import jp.co.sss.shop.repository.UserRepository;

/**
 * ログイン機能のコントローラクラス
 *
 * @author SystemShared
 */
@Controller
public class LoginController {

	/**
	 * 会員情報
	 */
	@Autowired
	UserRepository userRepository;

	/**
	 * セッション情報
	 */
	@Autowired
	HttpSession session;

	/**
	 * @param model
	 * @return
	 */
	@RequestMapping(path = "/login", method = RequestMethod.GET)
	public String login(Model model) {
		// リクエストスコープにフォームのデータが存在しない場合、生成して追加する
		if (!model.containsAttribute("loginForm")) {
			model.addAttribute("loginForm", new LoginForm());
		}
		
		session.removeAttribute("user");
		session.removeAttribute("basket");
		
		model.addAttribute("bodyClass", "login");
		
		return "login";
	}
	
	/**
	 * @param form
	 * @param result
	 * @param redirectAttributes
	 * @return
	 */
	@RequestMapping(path = "/login", method = RequestMethod.POST)
	public String doLogin(@Valid @ModelAttribute LoginForm form, 
			BindingResult result, RedirectAttributes redirectAttributes) {

		if (result.hasErrors()) {
			redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.loginForm", result);
			redirectAttributes.addFlashAttribute("loginForm", form);
			return "redirect:/login";
		} else {
			Integer authority = ((UserBean) session.getAttribute("user")).getAuthority();
			if (authority.intValue() == 2) {
				return "redirect:/";
			} else {
				return "redirect:/adminmenu";
			}
		}
	}

	/**
	 * @return
	 */
	@RequestMapping(path = "/adminmenu")
	public String showAdminMenu() {
		return "admin_menu";
	}
}