package jp.co.sss.shop.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import jp.co.sss.shop.entity.Item;

/**
 * itemsテーブル用リポジトリ
 *
 * @author System Shared
 */
@Repository
public interface ItemRepository extends JpaRepository<Item, Integer> {

	// 商品情報を新着順で検索
	public Page<Item> findByDeleteFlagOrderByInsertDateDesc(int deleteFlag, Pageable pageable);
	
	// 商品情報を新着順で検索(IDで降順)
	public Page<Item> findByDeleteFlagOrderByInsertDateDescIdDesc(int deleteFlag, Pageable pageable);
	
	// 選択されたカテゴリの商品情報を新着順で検索(IDで降順)
	@Query("SELECT i FROM Item i"
			+ " WHERE i.deleteFlag = 0 AND i.category.id = :categoryId"
			+ " ORDER BY i.insertDate DESC, i.id DESC")
	public Page<Item> findByCategoryIdOrderByInsertDateDescIdDesc(int categoryId, Pageable pageable);
	
	// 選択された価格帯の商品情報を新着順で検索(IDで降順)
	@Query("SELECT i FROM Item i"
			+ " WHERE i.deleteFlag = 0 AND i.price >= :min AND i.price <= :max"
			+ " ORDER BY i.insertDate DESC, i.id DESC")
	public Page<Item> findByPriceOrderByInsertDateDescIdDesc(@Param("min") int min,
			@Param("max") int max, Pageable pageable);
	
	// 商品情報を売れ筋順で上から10件検索(IDで昇順)
	@Query(value = "SELECT * FROM"
			+ " (SELECT i.* FROM items i LEFT OUTER JOIN order_items oi"
			+ " ON i.id = oi.item_id"
			+ " WHERE i.delete_flag = 0"
			+ " GROUP BY i.id, i.name, i.price, i.description, i.stock,"
			+ " i.image, i.category_id, i.delete_flag, i.insert_date"
			+ " ORDER BY COUNT(i.id) DESC, i.id)"
			+ " WHERE ROWNUM <= 10",
			nativeQuery = true)
	public List<Item> findTop10OrderByOrderTimes();
	
	// 商品情報を売れ筋順で検索(IDで昇順)
	@Query("SELECT i FROM Item i LEFT OUTER JOIN i.orderItemList oi"
			+ " WHERE i.deleteFlag = 0"
			+ " GROUP BY i.id, i.name, i.price, i.description, i.stock,"
			+ " i.image, i.deleteFlag, i.insertDate, i.category"
			+ " ORDER BY COUNT(i.id) DESC, i.id")
	public Page<Item> findAllOrderByOrderTimes(Pageable pageable);
	
	// 選択されたカテゴリの商品情報を売れ筋順で検索(IDで昇順)
	@Query("SELECT i FROM Item i LEFT OUTER JOIN i.orderItemList oi"
			+ " WHERE i.deleteFlag = 0 AND i.category.id = :categoryId"
			+ " GROUP BY i.id, i.name, i.price, i.description, i.stock,"
			+ " i.image, i.deleteFlag, i.insertDate, i.category"
			+ " ORDER BY COUNT(i.id) DESC, i.id")
	public Page<Item> findByCategoryIdOrderByOrderTimes(@Param("categoryId") int categoryId,
			Pageable pageable);
	
	// 選択された価格帯の商品情報を売れ筋順で検索(IDで昇順)
	@Query("SELECT i FROM Item i LEFT OUTER JOIN i.orderItemList oi"
			+ " WHERE i.deleteFlag = 0 AND i.price >= :min AND i.price <= :max"
			+ " GROUP BY i.id, i.name, i.price, i.description, i.stock,"
			+ " i.image, i.deleteFlag, i.insertDate, i.category"
			+ " ORDER BY COUNT(i.id) DESC, i.id")
	public Page<Item> findByPriceOrderByOrderTimes(@Param("min") int min,
			@Param("max") int max, Pageable pageable);

	// 主キーと削除フラグで検索
	public Item findByIdAndDeleteFlag(int id, int deleteFlag);
}
