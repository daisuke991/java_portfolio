package jp.co.sss.shop.controller.item;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import jp.co.sss.shop.bean.ItemBean;
import jp.co.sss.shop.entity.Item;
import jp.co.sss.shop.repository.ItemRepository;
import jp.co.sss.shop.util.BeanCopy;
import jp.co.sss.shop.util.Constant;

/**
 * 商品管理 一覧表示機能(一般会員用)のコントローラクラス
 *
 * @author SystemShared
 */
@Controller
public class ItemShowCustomerController {
	/**
	 * 商品情報
	 */
	@Autowired
	ItemRepository itemRepository;
	
	/**
	 * リクエスト情報
	 */
	@Autowired
	HttpServletRequest request;
	
	/**
	 * トップ画面 表示処理
	 *
	 * @param model    Viewとの値受渡し
	 * @param pageable ページング情報
	 * @return "/" トップ画面へ
	 */
	@RequestMapping(path = "/")
	public String index(Model model, Pageable pageable) {
		// 商品情報を人気順で10件取得
		List<Item> itemList = itemRepository.findTop10OrderByOrderTimes();
		
		// エンティティ内の検索結果をJavaBeansにコピー
		List<ItemBean> itemBeanList = BeanCopy.copyEntityToItemBean(itemList);
		
		// 商品情報をViewへ渡す
		model.addAttribute("items", itemBeanList);
		
		model.addAttribute("title", "トップ");
		model.addAttribute("bodyClass", "index");
		
		return "index";
	}
	
	/**
	 * @param sortType
	 * @param model
	 * @param pageable
	 * @return
	 */
	@RequestMapping(path = "/item/list/{sortType}")
	public String showAllItems(@PathVariable int sortType, Model model, Pageable pageable) {
		Page<Item> itemList = null;
		// 商品情報を全件検索
		if (sortType == 1) {
			// 新着順
			itemList = itemRepository.findByDeleteFlagOrderByInsertDateDescIdDesc(Constant.NOT_DELETED, pageable);			
		} else if (sortType == 2) {
			// 人気順
			itemList = itemRepository.findAllOrderByOrderTimes(pageable);
		}

		// エンティティ内の検索結果をJavaBeansにコピー
		List<ItemBean> itemBeanList = BeanCopy.copyEntityToItemBean(itemList.getContent());

		// 情報をViewへ渡す
		model.addAttribute("pages", itemList);
		model.addAttribute("items", itemBeanList);
		model.addAttribute("url", "/item/list/");

		model.addAttribute("title", "商品一覧");
		model.addAttribute("bodyClass", "item_list");
		
		return "item/list/item_list";
	}
	
	/**
	 * @param sortType
	 * @param categoryId
	 * @param model
	 * @param pageable
	 * @return
	 */
	@RequestMapping(path = "/item/list/category/{sortType}")
	public String searchByCategory(@PathVariable int sortType, int categoryId, Model model, Pageable pageable) {
		Page<Item> itemList = null;
		// 選択されたカテゴリの商品情報を検索
		if (sortType == 1) {
			// 新着順
			itemList = itemRepository.findByCategoryIdOrderByInsertDateDescIdDesc(categoryId, pageable);			
		} else if (sortType == 2) {
			// 人気順
			itemList = itemRepository.findByCategoryIdOrderByOrderTimes(categoryId, pageable);
		}

		// エンティティ内の検索結果をJavaBeansにコピー
		List<ItemBean> itemBeanList = BeanCopy.copyEntityToItemBean(itemList.getContent());

		// 情報をViewへ渡す
		model.addAttribute("pages", itemList);
		model.addAttribute("items", itemBeanList);
		model.addAttribute("categoryId", categoryId);
		model.addAttribute("url", "/item/list/category/");

		model.addAttribute("title", "商品一覧");
		model.addAttribute("bodyClass", "item_list");
	
		return "item/list/item_list";
	}
	
	/**
	 * @param sortType
	 * @param min
	 * @param max
	 * @param model
	 * @param pageable
	 * @return
	 */
	@RequestMapping(path = "/item/list/price/{sortType}")
	public String searchByPrice(@PathVariable int sortType, int min, int max, Model model, Pageable pageable) {
		Page<Item> itemList = null;
		// 選択された価格帯の商品情報を検索
		if (sortType == 1) {
			// 新着順
			itemList = itemRepository.findByPriceOrderByInsertDateDescIdDesc(min, max, pageable);			
		} else if (sortType == 2) {
			// 人気順
			itemList = itemRepository.findByPriceOrderByOrderTimes(min, max, pageable);
		}

		// エンティティ内の検索結果をJavaBeansにコピー
		List<ItemBean> itemBeanList = BeanCopy.copyEntityToItemBean(itemList.getContent());

		// 情報をViewへ渡す
		model.addAttribute("pages", itemList);
		model.addAttribute("items", itemBeanList);
		model.addAttribute("min", min);
		model.addAttribute("max", max);
		model.addAttribute("url", "/item/list/price/");

		model.addAttribute("title", "商品一覧");
		model.addAttribute("bodyClass", "item_list");
	
		return "item/list/item_list";
	}
	
	/**
	 * @param id
	 * @param model
	 * @return
	 */
	@RequestMapping(path = "/item/detail/{id}")
	public String showDetail(@PathVariable int id, Model model) {
		// 商品IDに該当する商品情報を取得
		Item item = itemRepository.findByIdAndDeleteFlag(id, 0);

		ItemBean itemBean = new ItemBean();

		// Itemエンティティの各フィールドの値をItemBeanにコピー
		BeanUtils.copyProperties(item, itemBean);

		// 商品情報にカテゴリ名を設定
		itemBean.setCategoryName(item.getCategory().getName());

		// 商品情報をViewへ渡す
		model.addAttribute("item", itemBean);
		
		// 遷移元のURL(クエリを含む)を取得する
		String referrer = request.getHeader("REFERER");
		
		// このアプリケーションのコンテキストパスまでのURLを取得
		String sharedShopPath = request.getScheme() + "://" + request.getServerName() + ":"
				+ request.getServerPort() + request.getContextPath();
		
		// 遷移元がこのアプリケーション内である場合、
		// 遷移元URLをパスとクエリに分解して遷移先のViewへ渡す
		if (referrer != null && referrer.startsWith(sharedShopPath)) {
			String referringUrl = referrer;
			
			// 遷移元URL文字列が"?"を含む場合、クエリからパラメータの値を取得してViewへ渡す
			if (referrer.contains("?")) {
				int questionMarkIndex = referrer.indexOf("?");
				
				// "?"より前の文字列をパスとして取得し、referringUrlを更新する
				referringUrl = referrer.substring(0, questionMarkIndex);
				
				// "?"以降の文字列をクエリとして取得する
				String queryStr = referrer.substring(questionMarkIndex);
				
				String categoryParam = "categoryId=";
				String minParam = "min=";
				String maxParam = "max=";
				String pageParam = "page=";
				
				// クエリがカテゴリIDをパラメータとして持つ場合、その値を取得してViewへ渡す
				if (queryStr.contains(categoryParam)) {
					int biginIndex = queryStr.indexOf(categoryParam) + categoryParam.length();
					String categoryIdStr = queryStr.substring(biginIndex);
					if (categoryIdStr.contains("&")) {
						int endIndex = queryStr.indexOf("&", biginIndex);
						categoryIdStr = queryStr.substring(biginIndex, endIndex);
					}
					int categoryId = Integer.parseInt(categoryIdStr);
					model.addAttribute("categoryId", categoryId);
				}
				
				// クエリが価格帯情報をパラメータとして持つ場合、その値を取得してViewへ渡す
				if (queryStr.contains(minParam) && queryStr.contains(maxParam)) {
					int biginIndexMin = queryStr.indexOf(minParam) + minParam.length();
					int endIndexMin = queryStr.indexOf("&", biginIndexMin);
					String minStr = queryStr.substring(biginIndexMin, endIndexMin);
					int min = Integer.parseInt(minStr);
					
					int biginIndexMax = queryStr.indexOf(maxParam) + maxParam.length();
					String maxStr = queryStr.substring(biginIndexMax);
					if (maxStr.contains("&")) {
						int endIndexMax = queryStr.indexOf("&", biginIndexMax);
						maxStr = queryStr.substring(biginIndexMax, endIndexMax);
					}
					int max = Integer.parseInt(maxStr);
					
					model.addAttribute("min", min);
					model.addAttribute("max", max);
				}
				
				// クエリがページ番号をパラメータとして持つ場合、その値を取得してViewへ渡す
				if (queryStr.contains(pageParam)) {
					int biginIndex = queryStr.indexOf(pageParam) + pageParam.length();
					String pageStr = queryStr.substring(biginIndex);
					int page = Integer.parseInt(pageStr);
					model.addAttribute("page", page);
				}
			}
			
			// 遷移元URLのパスをViewへ渡す
			model.addAttribute("referringUrl", referringUrl);
		}
		
		model.addAttribute("title", "商品詳細");
		model.addAttribute("bodyClass", "item_detail");
		
		return "item/detail/item_detail";
	}
}
