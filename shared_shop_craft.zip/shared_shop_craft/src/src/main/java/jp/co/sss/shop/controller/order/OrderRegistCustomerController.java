package jp.co.sss.shop.controller.order;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jp.co.sss.shop.bean.BasketBean;
import jp.co.sss.shop.bean.OrderBean;
import jp.co.sss.shop.bean.OrderItemBean;
import jp.co.sss.shop.bean.UserBean;
import jp.co.sss.shop.entity.Item;
import jp.co.sss.shop.entity.Order;
import jp.co.sss.shop.entity.OrderItem;
import jp.co.sss.shop.entity.User;
import jp.co.sss.shop.form.OrderForm;
import jp.co.sss.shop.repository.ItemRepository;
import jp.co.sss.shop.repository.OrderItemRepository;
import jp.co.sss.shop.repository.OrderRepository;
import jp.co.sss.shop.repository.UserRepository;
import jp.co.sss.shop.util.PriceCalc;

@Controller
public class OrderRegistCustomerController {

	/**
	 * 注文情報
	 */
	@Autowired
	OrderRepository orderRepository;
	
	/**
	 * 注文商品情報
	 */
	@Autowired
	OrderItemRepository orderItemRepository;

	/**
	 * 商品情報
	 */
	@Autowired
	ItemRepository itemRepository;

	/**
	 * 会員情報
	 */
	@Autowired
	UserRepository userRepository;

	/**
	 * セッション
	 */
	@Autowired
	HttpSession session;

	/**
	 * @param backFlg
	 * @param model
	 * @param orderForm
	 * @param result
	 * @return
	 */
	@RequestMapping(path = "/address/input", method = RequestMethod.POST)
	public String inputAddress(boolean backFlg, Model model, @ModelAttribute OrderForm orderForm,
			BindingResult result) {
		// 戻るボタン以外から遷移してきた場合、ログイン中のユーザー情報から届け先情報を取得する
		// 戻るボタンから遷移してきた場合、OrderFormから注文情報を取得する
		if (!backFlg) {
			Integer id = ((UserBean) session.getAttribute("user")).getId();
			User user = userRepository.getOne(id);
			BeanUtils.copyProperties(user, orderForm);
		}
		
		// 注文情報をViewに渡す
		model.addAttribute("orderForm", orderForm);
		
		model.addAttribute("title", "お届け先入力");
		model.addAttribute("bodyClass", "order_address_input");
	
		return "order/regist/order_address_input";
	}

	/**
	 * @param model
	 * @return
	 */
	@RequestMapping(path = "/address/input", method = RequestMethod.GET)
	public String inputAddressRedirect(Model model) {

		model.addAttribute("title", "お届け先入力");
		model.addAttribute("bodyClass", "order_address_input");
	
		return "order/regist/order_address_input";
	}

	/**
	 * @param backFlg
	 * @param model
	 * @param orderForm
	 * @param result
	 * @param redirectAttributes
	 * @return
	 */
	@RequestMapping(path = "/payment/input", method = RequestMethod.POST)
	public String inputPayment(boolean backFlg, Model model, @Valid @ModelAttribute OrderForm orderForm,
			BindingResult result, RedirectAttributes redirectAttributes) {
		// 戻るボタン以外から遷移してきた場合、入力チェック結果を評価する
		// 戻るボタンから遷移してきた場合、OrderFormから注文情報を取得する
		if (!backFlg) {
			// 入力チェック結果より、エラーがあればお届け先入力画面にリダイレクトする
			// エラーがなければ、OrderFormから注文情報を取得する
			if (result.hasErrors()) {
				redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.orderForm", result);
				redirectAttributes.addFlashAttribute("orderForm", orderForm);

				return "redirect:/address/input";
			} else {
				OrderBean orderBean = new OrderBean();

				// OrderFormの各フィールドの値をOrderBeanにコピー
				BeanUtils.copyProperties(orderForm, orderBean);

				// 注文情報をViewに渡す
				model.addAttribute("order", orderBean);

				model.addAttribute("title", "お支払い方法選択");
				model.addAttribute("bodyClass", "order_payment_input");
			
				return "order/regist/order_payment_input";
			}
		} else {
			OrderBean orderBean = new OrderBean();

			// OrderFormの各フィールドの値をOrderBeanにコピー
			BeanUtils.copyProperties(orderForm, orderBean);

			// 注文情報をViewに渡す
			model.addAttribute("order", orderBean);

			model.addAttribute("title", "お支払い方法選択");
			model.addAttribute("bodyClass", "order_payment_input");
		
			return "order/regist/order_payment_input";
		}
	}

	/**
	 * @param model
	 * @param orderForm
	 * @param attributes
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(path = "/order/check", method = RequestMethod.POST)
	public String checkOrder(Model model, OrderForm orderForm, RedirectAttributes attributes) {

		List<BasketBean> basketList = (List<BasketBean>) session.getAttribute("basket");
		
		List<OrderItemBean> orderItemList = new ArrayList<OrderItemBean>();
		
		List<OrderItemBean> noStockItemList = new ArrayList<OrderItemBean>();
		List<OrderItemBean> shortStockItemList = new ArrayList<OrderItemBean>();

		// 買い物かご内の商品をその在庫数を確認した上でOrderItemListに追加する
		for (BasketBean basket : basketList) {	
			OrderItemBean orderItem = new OrderItemBean();
			
			// データベースから商品情報を主キー検索で取得する
			Item item = itemRepository.getOne(basket.getId());
			
			BeanUtils.copyProperties(item, orderItem);
			
			Integer stock = item.getStock();
			basket.setStock(stock);
			
			// 在庫数が0のとき、noStockItemListに追加する
			// 在庫不足のとき、在庫数分を注文数とし、shortStockItemListに追加する
			// 在庫がある場合、小計を算出してorderItremListに追加する
			if (stock == 0) {
				noStockItemList.add(orderItem);
			} else if (stock < basket.getOrderNum()) {
				// 在庫数を注文数として小計を算出する
				basket.setOrderNum(stock);
				orderItem.setOrderNum(basket.getOrderNum());
				int subtotal = orderItem.getPrice() * orderItem.getOrderNum();
				orderItem.setSubtotal(subtotal);
				
				shortStockItemList.add(orderItem);
				orderItemList.add(orderItem);
			} else {
				// 注文数をそのままセットして小計を算出する
				orderItem.setOrderNum(basket.getOrderNum());
				int subtotal = orderItem.getPrice() * orderItem.getOrderNum();
				orderItem.setSubtotal(subtotal);
				
				orderItemList.add(orderItem);
			}
		}
		
		// 上記for文内でbasketListの要素を削除するとConcurrentModificationExceptionが発生するので、
		// 下記の方法でnoStockItemListの要素とIDが一致する商品情報を買い物かごから削除する
		for (OrderItemBean noStockItem : noStockItemList) {
			basketList.removeIf(basket -> basket.getId() == noStockItem.getId());
		}
		
		// 合計金額を算出する
		int price = PriceCalc.orderItemPriceTotal(orderItemList);
		
		// OrderFormの各フィールドの値をOrderBeanにコピー
		OrderBean order = new OrderBean();
		BeanUtils.copyProperties(orderForm, order);
		
		// 注文情報をViewへ渡す
		model.addAttribute("order", order);
		model.addAttribute("price", price);
		model.addAttribute("orderItems", orderItemList);
		model.addAttribute("noStockItems", noStockItemList);
		model.addAttribute("shortStockItems", shortStockItemList);

		model.addAttribute("title", "注文内容最終確認");
		model.addAttribute("bodyClass", "order_check");
	
		return "order/regist/order_check";
	}

	/**
	 * @param orderForm
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(path = "/order/complete", method = RequestMethod.POST)
	public String completeOrder(@ModelAttribute OrderForm orderForm) {
		// OrderFormの各フィールドの値をOrderエンティティにコピー
		Order order = new Order();
		BeanUtils.copyProperties(orderForm, order);
		
		// ログイン中のユーザーの情報をデータベースから取得し、Orderエンティティにセットする
		UserBean userBean = (UserBean) session.getAttribute("user");
		User user = userRepository.getOne(userBean.getId());
		order.setUser(user);
		
		// 注文情報を保存
		orderRepository.save(order);
		
		List<OrderItemBean> orderItemList = new ArrayList<OrderItemBean>();
		
		List<BasketBean> basketList = (List<BasketBean>) session.getAttribute("basket");

		// 買い物かご内の商品をその在庫数を確認した上でOrderItemListに追加する
		for (BasketBean basket : basketList) {
			OrderItemBean orderItemBean = new OrderItemBean();
			Item item = itemRepository.getOne(basket.getId());
			
			// 在庫があればOrderItemListに追加する
			if (item.getStock() > 0) {
				// Itemエンティティの各フィールドの値をOrderItemBeanにコピー
				BeanUtils.copyProperties(item, orderItemBean);
				
				// 在庫が足りていれば、注文数をそのもまセットする
				// 在庫が不足していれば、在庫数分を注文数とする
				if (basket.getOrderNum() <= item.getStock()) {
					orderItemBean.setOrderNum(basket.getOrderNum());
				} else {
					orderItemBean.setOrderNum(item.getStock());
				}
				
				orderItemList.add(orderItemBean);
			}
		}
		
		// 注文商品情報をデータベースに保存し、商品の在庫数を変更する
		for (OrderItemBean orderItemBean : orderItemList) {
			OrderItem orderItem = new OrderItem();
			
			// 注文数をセットする
			orderItem.setQuantity(orderItemBean.getOrderNum());
			
			// 注文情報をセットする
			orderItem.setOrder(order);
			
			// 商品情報をデータベースから取得してセットする
			Integer itemId = orderItemBean.getId();
			Item item = itemRepository.getOne(itemId);
			orderItem.setItem(item);
			
			// 注文時点商品単価をセットする
			orderItem.setPrice(item.getPrice());
			
			// 注文商品情報を保存
			orderItemRepository.save(orderItem);
			
			// 注文された商品の在庫数を注文数分減らす
			Integer stock = item.getStock();
			stock -= orderItem.getQuantity();
			item.setStock(stock);
			
			// 商品情報を保存
			itemRepository.save(item);
		}
		
		// 買い物かご情報をセッションから破棄する
		session.removeAttribute("basket");
		
		return "redirect:/order/complete";
	}

	/**
	 * @param model
	 * @return
	 */
	@RequestMapping(path = "/order/complete", method = RequestMethod.GET)
	public String completeOrderRedirect(Model model) {
		
		model.addAttribute("title", "注文完了");
		model.addAttribute("bodyClass", "order_complete");
		
		return "order/regist/order_complete";
	}
}