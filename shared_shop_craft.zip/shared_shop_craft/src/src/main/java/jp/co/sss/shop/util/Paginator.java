package jp.co.sss.shop.util;

import java.util.Collections;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import jp.co.sss.shop.bean.BasketBean;

/**
 * リストをページングするクラス
 * 
 * @author
 *
 */
@Service
public class Paginator {
	
	/**
	 * 買い物かご情報リストをページングするメソッド
	 * 
	 * @param basketList
	 * @param pageable
	 * @return
	 */
	public Page<BasketBean> paginate(List<BasketBean> basketList, Pageable pageable) {
		int pageSize = pageable.getPageSize();
		int currentPage = pageable.getPageNumber();
		int startItem = currentPage * pageSize;
		List<BasketBean> list;

		if (basketList.size() < startItem) {
			list = Collections.emptyList();
		} else {
			int toIndex = Math.min(startItem + pageSize, basketList.size());
			list = basketList.subList(startItem, toIndex);
		}

		Page<BasketBean> bookPage = new PageImpl<BasketBean>(list, PageRequest.of(currentPage, pageSize),
				basketList.size());

		return bookPage;
	}
}
