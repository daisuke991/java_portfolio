package jp.co.sss.shop.controller.user;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import jp.co.sss.shop.bean.UserBean;
import jp.co.sss.shop.entity.User;
import jp.co.sss.shop.form.UserForm;
import jp.co.sss.shop.repository.UserRepository;
import jp.co.sss.shop.util.BeanCopy;

/**
 * 会員管理 表示機能(一般会員)のコントローラクラス
 *
 * @author LenaKurata
 */
@Controller
public class UserShowCustomerController {
	/**
	 * 会員情報
	 */
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	HttpSession session;

	/**
	 * 会員詳細表示処理
	 *
	 * @param model   Viewとの値受渡し
	 * @param form    会員情報フォーム
	 * @return "/user/detail/user_detail" 会員詳細表示画面へ
	 */
	@RequestMapping(path = "/user/detail")
	public String showUser(Model model, @ModelAttribute UserForm form) {
		// 表示対象の会員情報を取得
		UserBean userBean = (UserBean) session.getAttribute("user");
		
		if (userBean != null) {
			Integer id = userBean.getId();
			User user = userRepository.getOne(id);
			
			//会員のメールアドレス、郵便番号、住所を表示させるための値渡し処理
			userBean = BeanCopy.copyEntityToBean(user);
			
			// 会員情報をViewに渡す
			model.addAttribute("user", userBean);
		}
		
		model.addAttribute("title", "会員詳細");
		model.addAttribute("bodyClass", "user_detail");

		return "/user/detail/user_detail";
	}
}
