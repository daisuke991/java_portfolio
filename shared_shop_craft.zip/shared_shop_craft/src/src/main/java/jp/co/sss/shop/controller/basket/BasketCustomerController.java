package jp.co.sss.shop.controller.basket;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jp.co.sss.shop.bean.BasketBean;
import jp.co.sss.shop.entity.Item;
import jp.co.sss.shop.repository.ItemRepository;
import jp.co.sss.shop.util.Paginator;

/**
 * @author 
 *
 */
@Controller
public class BasketCustomerController {

	@Autowired
	ItemRepository itemRepository;

	@Autowired
	HttpSession session;
	
	@Autowired
	Paginator paginator;

	/**
	 * 買い物かごの商品を一覧表示する
	 * 
	 * @param model
	 * @param pageable
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(path = "/basket/list", method = RequestMethod.GET)
	public String basketList(Model model, Pageable pageable) {
		// セッションから買い物かご情報を取得する
		Object sessionBasket = session.getAttribute("basket");
		
		// 買い物かご情報が存在する場合
		if (sessionBasket != null) {
			// 買い物かご情報をキャストしてリストに代入する
			List<BasketBean> basketList = (List<BasketBean>) sessionBasket;

			// 買い物かごに商品が1つもない場合、セッションの買い物かご情報を破棄する
			// 商品がある場合は、ページングしてViewへ渡す
			if (basketList.size() == 0) {
				session.removeAttribute("basket");
			} else {
				// 買い物かご情報リストをページングする
				Page<BasketBean> basketPage = paginator.paginate(basketList, pageable);
				
				// ページングされた買い物かご情報からリストを取得する
				basketList = basketPage.getContent();
				
				// 情報をViewへ渡す
				model.addAttribute("pages", basketPage);
				model.addAttribute("items", basketList);
				model.addAttribute("url", "/basket/list");
			}
		}
		
		model.addAttribute("title", "買い物かご");
		model.addAttribute("bodyClass", "shopping_basket");
		
		return "basket/shopping_basket";
	}
	
	/**
	 * 買い物かごに商品を追加する
	 * 
	 * @param id
	 * @param model
	 * @param attributes
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(path = "/basket/add", method = RequestMethod.POST)
	public String addItem(int id, Model model, RedirectAttributes attributes) {
		// 買い物かごリストを宣言する
		List<BasketBean> basketList;
		
		// セッションから買い物かご情報を取得する
		Object sessionBasket = session.getAttribute("basket");
		
		// セッションに買い物かご情報が存在しない場合、
		// リストを新規作成し、セッションスコープに登録する
		// 買い物かご情報が存在する場合は、それをリストに代入する
		if (sessionBasket == null) {
			basketList = new ArrayList<BasketBean>();
			session.setAttribute("basket", basketList);
		} else {
			basketList = (List<BasketBean>) sessionBasket;
		}
		
		// 選択された商品の情報をデータベースから取得する
		Item item = itemRepository.getOne(id);
		String name = item.getName();
		Integer stock = item.getStock();
		
		// 該当商品が追加済みか否かを示す真偽値を宣言し、初期値をfalseとする
		boolean hasBeenAdded = false;
		
		// 該当商品がリスト内に存在すれば、hasBeenAddedをtrueにし、在庫数に応じた処理を行う
		for (BasketBean basket : basketList) {
			if (basket.getId() == id) {
				hasBeenAdded = true;

				// かご内の商品情報を最新のものに更新する
				basket.setName(name);
				basket.setStock(stock);
				
				// 在庫数が0のとき買い物かごから削除し、noStockFlagを立てる
				// 在庫不足のとき在庫数と注文数を変更し、shortStockFlagを立てる
				// 在庫が十分あるとき、該当商品の注文個数を1つ増やす
				if (stock == 0) {
					basketList.remove(basket);
					attributes.addFlashAttribute("noStockFlag", true);
				} else if (stock <= basket.getOrderNum()) {
					basket.setOrderNum(stock);
					attributes.addFlashAttribute("shortStockFlag", true);
				} else {
					basket.setOrderNum(basket.getOrderNum() + 1);
				}
				break;
			}
		}
		
		// 該当商品が追加済みでない場合、在庫数が0のときnoStockFlagを立て、
		// 在庫が十分あるとき、商品情報をリストの先頭に新規追加する
		if (hasBeenAdded == false) {
			if (stock == 0) {
				attributes.addFlashAttribute("noStockFlag", true);
			} else {
				BasketBean basket = new BasketBean(id, name, stock);
				basketList.add(0, basket);
			}
		}
		
		// 該当商品の商品名をリダイレクト先のViewに渡す
		attributes.addFlashAttribute("itemName", name);
		
		return "redirect:/basket/list";
	}

	/**
	 * 買い物かごから商品を1つ減らす
	 * 
	 * @param id
	 * @param model
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(path = "basket/delete", method = RequestMethod.POST)
	public String deleteItem(int id, Model model) {
		// セッションから買い物かご情報を取得し、キャストしてリストに代入する
		List<BasketBean> basketList = (List<BasketBean>) session.getAttribute("basket");
		
		// 該当商品をリストから探し出し、削除処理を行う
		for (BasketBean basket : basketList) {
			if (basket.getId() == id) {
				// 該当商品の注文個数が1のとき、買い物かご情報から該当商品を削除する
				// 2以上のときは、該当商品の注文個数を1つ減少させる
				if (basket.getOrderNum() == 1) {
					basketList.remove(basket);
				} else if (basket.getOrderNum() >= 2) {
					basket.setOrderNum(basket.getOrderNum() - 1);
				}
				break;
			}
		}
		
		return "redirect:/basket/list";
	}

	/**
	 * 買い物かごを空にする
	 * 
	 * @return
	 */
	@RequestMapping(path = "basket/allDelete", method = RequestMethod.POST)
	public String deleteAll() {
		
		// セッションの買い物かご情報を破棄する
		session.removeAttribute("basket");
		
		return "redirect:/basket/list";
	}
}